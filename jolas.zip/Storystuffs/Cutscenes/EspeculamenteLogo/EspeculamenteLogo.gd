extends Node2D
@export var especulaTrail:IntroPlaneTrail
@export var gTetoPlane:Node2D

var coolIntroy = [
	['', '', 'B', '', ''],
	['', 'B', '', 'B', ''],
	['B', '', '', '', 'B'],
	['c', '', '', '', 'c'],
	['', 'c', '', 'c', ''],
	['B', 'B', 'c', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['c', '', '', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['', '', '', '', ''],
	['', 'c', 'c', '', ''],
	['', '', '', '', '']
]

var curLine:int = -1
var gtetoPlaned:bool = false

func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("ctrl_pause"):
		onAnimFinish(&"intro")
	
	if not gtetoPlaned:
		especulaTrail.position = gTetoPlane.position
	
	if especulaTrail.elapsed % especulaTrail.framesBetweenAdd > 0:
		return
		
	if curLine < len(coolIntroy) and curLine >= 0:
		if curLine > -1:
			especulaTrail.lineOut(coolIntroy[curLine])
			print('line added:', coolIntroy[curLine], '(', curLine, ')')
		if curLine == len(coolIntroy):
			gtetoPlaned = true
			especulaTrail.done = true
		curLine += 1

func getStarted():
	curLine = 0

func onAnimFinish(anim_name: StringName) -> void:
	if anim_name == &"intro":
		get_tree().change_scene_to_file("res://Menustuffs/Menu.tscn")
