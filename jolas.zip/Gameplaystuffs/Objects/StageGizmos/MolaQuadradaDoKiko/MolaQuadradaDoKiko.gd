@tool
extends Node2D
class_name MolaQuadradaDoKiko

@export_category("SpringSetup")
## força da mola. ela tem uma preview demonstrada no editor com a linha vede
@export_range(0.0, 10000.0) var launch_force: float = 1000.0:
	set(v):
		launch_force = v
		queue_redraw()

## velocidade de animacao da mola
@export_range(0.1, 5.0, 0.1) var spring_speed: float = 1.0

@onready var animation_player: AnimationPlayer = $AnimationPlayer
@export_category("Tech Stuff")
## posicao onde o player ficará preso
@export var player_position: Marker2D
## som da mola
@export var spring_sound: AudioStreamPlayer2D

var current_object: CharacterBody2D

func _ready() -> void:
	if Engine.is_editor_hint():
		queue_redraw()
	set_notify_transform(true)
	animation_player.speed_scale = spring_speed

func _draw() -> void:
	var preview_size := launch_force * 0.35
	
	# Compensa a escala global do node
	var scale_compensation := Vector2.ONE / global_scale
	
	var direction := Vector2.UP * preview_size
	
	if Engine.is_editor_hint():
		draw_line(
			player_position.position,
			player_position.position + (direction * scale_compensation),
			Color.GREEN,
			8.0 / global_scale.length()
		)

func _physics_process(_delta: float) -> void:
	if Engine.is_editor_hint():
		return
	$MolaGames/MolaCima.scale.y = 1 / $MolaGames.scale.y
	if current_object:
		if current_object is PlayerObject:
			#current_object.change_state(current_object.state_machine.st_default)
			current_object.jumping = false
			current_object.motion = Vector2.ZERO
			current_object.global_position = (player_position.global_position - Vector2(0.0, (current_object.player_collisions.shape.size.y) / 2).rotated(rotation))
		elif current_object is MobObject:
			current_object.velocity = Vector2.ZERO
			current_object.global_position = (player_position.global_position - Vector2(0.0, (current_object.collisions.shape.size.y) / 2).rotated(rotation))

func _on_area_2d_body_entered(body: Node2D) -> void:
	if Engine.is_editor_hint():
		return
	if current_object == null and not animation_player.is_playing():
		if body is PlayerObject:
			current_object = body
			current_object.walkingEnabled = false
			current_object.on_pre_spring()
			animation_player.play("mola_quadrada_do_kiko/boingoing")
		if body is MobObject:
			current_object = body
			animation_player.play("mola_quadrada_do_kiko/boingoing")

func release_player():
	if not current_object or Engine.is_editor_hint():
		return
		
	play_sfx(spring_sound)
	
	if current_object is PlayerObject:
		if not current_object.current_state == current_object.state_machine.st_air:
			current_object.change_state(current_object.state_machine.st_air)
			
		await get_tree().process_frame # perdao isso VAI ocorrer novamente
		
		current_object.motion = get_launch_velocity(current_object)
		if current_object.motion.x != 0.0:
			current_object.plySprite.flip_h = false if sign(current_object.motion.x) > 0.0 else true
		current_object.walkingEnabled = true
		current_object.jumping = false
		current_object.jumpsDone = 99
		current_object.on_spring(get_launch_velocity(current_object))
	
	elif current_object is MobObject:
		if current_object.hp <= 0:
			return
		current_object.velocity = get_launch_velocity(current_object)
	
	current_object = null

#region Utilities
func get_launch_direction() -> Vector2:
	return Vector2.UP.rotated(rotation)

func get_launch_velocity(body) -> Vector2:
	var gravity_ratio: float = sqrt(body.GRAVITY / 25.0)
	# print('ratio da mola: ', gravity_ratio)
	
	return get_launch_direction() * launch_force * Vector2(1, gravity_ratio)

func play_sfx(sfx: AudioStreamPlayer2D):
	# sfx.volume_db = GeneralUtils.get_volume_db('sfx')
	# reliquia de um tempo passado...
	sfx.play()
	sfx.pitch_scale = randf_range(0.8, 1.2)
	
func _notification(what):
	if what == NOTIFICATION_TRANSFORM_CHANGED:
		queue_redraw()
#endregion
