extends CharacterBody2D
class_name BossObject

# ok uhhhhhhhhhh O boss e basicamente um mob so que mais op
# iuhul
#region State Machine
@onready var state_machine: Node = $StateMachine
var current_state = null
var previous_state = null
#endregion

#region Params
@export_group('Parameters')
@export var ACCELERATION = 62.5
@export var MAX_SPEED = 600
@export var GRAVITY = 25.0
@export var JUMP_VELOCITY = -625
@export var FRICTION = 0.9125

@export var maxHP:float = 10
@onready var hp:float = maxHP
@export var level:float = 1.0
@export var strength:float = 1.0
@export var xpGrant:float = 10.0

@export var USES_BODY_AS_HITBOX:bool = true

@export var CUSTOM_BOSS_MUSIC:String = ""

@export var KNOCKBACK_ON_PLY_BODY_HIT:Vector2 = Vector2(250, -250)

## uma chance de 1 em quantos pra dropar esse item ?
@export var possibleDrops:Dictionary[String, int] = {}

@export_group('Technical shit')
@export var collisions:CollisionShape2D

@export var collArea:Area2D
@export var collAreaCollision:CollisionShape2D

@export var sfx_player:AudioStreamPlayer2D

@export var healthBar:Bar

@export_category('Animations')
@export var leSprite:AnimatedSprite2D
#endregion 

#region Othershits
var detectingPlayer:bool = false

var touchingPlayer:bool = false
var touchedPlayer:PlayerObject
var touchedBody

var theHarmer:PlayerObject

var isHurting := false
var isDead := false

signal boss_start
signal boss_dead

var stunFrames:float = 0.0
#endregion

func _ready() -> void:
	collAreaCollision.shape = collisions.shape
	collAreaCollision.scale = collisions.scale
	
	# comece a state machine
	for state in state_machine.get_children():
		state.States = state_machine
		state.Boss = self
		state.StateName = state.name
	current_state = state_machine.st_dormant
	previous_state = state_machine.st_dormant
	
	collArea.connect("body_entered", onTouched)
	collArea.connect("body_exited", onUntouched)

func _physics_process(delta: float) -> void:
	healthBar.progress = hp / maxHP
	
	if stunFrames > 0:
		stunFrames -= 1 * delta * 60
		return
	if current_state.has_method('update'): current_state.update()
	# $Label.text = GeneralUtils.display_number(hp) + '/' + GeneralUtils.display_number(maxHP)
	move_and_slide()

func handlePhys():
	if !is_on_floor():
		velocity.y += GRAVITY
		
	if is_on_wall():
		velocity.x = 0

func change_state(new_state):
	if new_state != null:
		# muda os estados
		previous_state = current_state
		current_state = new_state
		# ativa as funcoes dos estados
		previous_state.exit_state()
		current_state.enter_state()

# touchy
func onTouched(body):
	touchedBody = body
	if body is PlayerObject:
		touchedPlayer = body
		touchingPlayer = true

func onUntouched(body):
	if body == touchedBody:
		touchedBody = null
	if body is PlayerObject:
		if body == touchedPlayer:
			touchedPlayer = null
		touchingPlayer = false

# woah mais coisas copiadas do player
func yeowch(hpLost:float, vel:Vector2 = Vector2(250, -250)):
	# print(vel)
	if isDead or current_state == state_machine.st_dormant:
		return false
	spawnNumber(hpLost)
	if theHarmer:
		theHarmer.increaseCombo()
	stunFrames = 2.0
	hp -= hpLost
	on_hurt(hpLost, {'vel': vel})
	if (hp <= 0):
		if theHarmer: 
			theHarmer.add_xp(xpGrant)
		change_state(state_machine.st_death)
		dropItems()
		isDead = true
		boss_dead.emit()
	else:
		change_state(state_machine.st_hurt)
	return true

func on_hurt(hpLost:float, extra:Dictionary):
	var medianVel = (extra['vel'].x + extra['vel'].y)/2
	if medianVel < 400:
		play_sfx('Hit1', 5)
	if medianVel >= 400 and medianVel < 800:
		play_sfx('Hit2', 5)
	if medianVel >= 800:
		play_sfx('Hit3', 5)
	velocity.y = extra['vel'].y
	velocity.x = extra['vel'].x

func play_sfx(soundName:String, volumeDB:float = 0.0, pitch_scale: float = 1.0, file_type: String = ".wav"):
	if sfx_player.playing: sfx_player.stop()
	sfx_player.stream = load("res://Soundstuffs/SFX/Ingame/" + soundName + file_type)
	sfx_player.volume_db = volumeDB
	sfx_player.pitch_scale = pitch_scale
	sfx_player.play()

func play_boss_sfx(name:String, boss:String, volumeDB:float = 0.0, pitch_scale: float = 1.0, file_type: String = ".wav"):
	if sfx_player.playing: sfx_player.stop()
	sfx_player.stream = load("res://Gameplaystuffs/Bosses/" + boss + "/Sounds/" + name + file_type)
	sfx_player.volume_db = volumeDB
	sfx_player.pitch_scale = pitch_scale
	sfx_player.play()

#woah uma coisa Simulando o player ?
func inputSimulation(xInput:int, yInput:int):
	if xInput != 0:
		if abs(velocity.x) < MAX_SPEED:
			velocity.x += ACCELERATION * xInput
	elif is_on_floor():
		velocity.x = velocity.x * FRICTION
	
	if yInput == -1:
		if is_on_floor():
			velocity.y -= JUMP_VELOCITY

# detector de player
func pd_body_entered(body: Node2D) -> void:
	if body is PlayerObject:
		detectingPlayer = true

func pd_body_exited(body: Node2D) -> void:
	if body is PlayerObject:
		detectingPlayer = false

# voce pode tentar combar eles agora
func handlePlyHits(harmPlayer:bool = true):
	if touchingPlayer && USES_BODY_AS_HITBOX:
		if harmPlayer:
			theHarmer = null
			touchedPlayer.yeowch(strength, KNOCKBACK_ON_PLY_BODY_HIT)

func spawnNumber(quant):
	var numble = load("res://Gameplaystuffs/UsefulShits/Numbs.tscn").instantiate()
	get_parent().add_child(numble)
	numble.global_position = global_position - Vector2(0, 32)
	numble.set_text(quant)

func dropItems():
	if len(possibleDrops) > 0:
		for itemcool in possibleDrops:
			if randi_range(1, possibleDrops[itemcool]) == 1:
				MapUtils.spawn_item(itemcool, global_position)

func awake():
	JolasGame.instance.fadeBGM()
	await get_tree().create_timer(2).timeout
	healthBar.visible = true
	change_state(state_machine.st_default)
	JolasGame.instance.playBGM(CUSTOM_BOSS_MUSIC if CUSTOM_BOSS_MUSIC != "" else "ULTRAKILLCybergrind.ogg")
