extends Node

# Autoload named Lobby

# These signals can be connected to by a UI lobby scene or the game scene.
signal player_connected(peer_id, player_info)
signal player_disconnected(peer_id)
signal server_disconnected
signal bye_bye

const DEFAULT_SERVER_IP = "127.0.0.1" # IPv4 localhost
const MAX_CONNECTIONS = 20

# This will contain player info for every player,
# with the keys being each player's unique IDs.
var players = {}

# This is the local player info. This should be modified locally
# before the connection is made. It will be passed to every other peer.
# For example, the value of "name" can be set to something the player
# entered in a UI scene.
var player_info = 	{
					"name": "",
					"char": GPStats.char,
					"loaded-mods": ModUtils.loadedMods,
					"connTest": false
					}
					
var players_loaded = 0

func _ready():
	multiplayer.peer_connected.connect(_on_player_connected)
	multiplayer.peer_disconnected.connect(_on_player_disconnected)
	
	multiplayer.connected_to_server.connect(_on_connected_ok)
	multiplayer.connection_failed.connect(_on_connected_fail)
	
	multiplayer.server_disconnected.connect(_on_server_disconnected)

func join_game(address = ""):
	if address.is_empty():
		address = DEFAULT_SERVER_IP
	var peer = ENetMultiplayerPeer.new()
	var error = peer.create_client(address, OnlineUtils.portEntered)
	if error:
		remove_multiplayer_peer()
		return error
	multiplayer.multiplayer_peer = peer

func create_game():
	OnlineUtils.setupUPNPThreaded()
	var peer = ENetMultiplayerPeer.new()
	var error = peer.create_server(OnlineUtils.portEntered, MAX_CONNECTIONS)
	if error:
		return error
	multiplayer.multiplayer_peer = peer

	players[1] = player_info
	player_connected.emit(1, player_info)
	print('[MULTIPLAYER] Server aberto na porta %s' % OnlineUtils.portEntered)
	OnlineUtils.sendServerHeartbeat()

func remove_multiplayer_peer():
	if multiplayer != null:
		multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	players.clear()
	bye_bye.emit()

# When the server decides to start the game from a UI scene,
# do Lobby.load_game.rpc(filepath)
@rpc("call_local", "reliable")
func load_game(game_scene_path):
	GeneralUtils.loadScene(game_scene_path)

# Every peer will call this when they have loaded the game scene.
@rpc("any_peer", "call_local", "reliable")
func player_loaded():
	if multiplayer.is_server():
		players_loaded += 1
		if players_loaded == players.size():
			print('[MULTIPLAYER] yeah dude')

# When a peer connects, send them my player info.
# This allows transfer of all desired data for each player, not only the unique ID.
func _on_player_connected(id):
	if not GPStats.is_dedicated_server:
		_register_player.rpc_id(id, player_info)

@rpc("any_peer", "reliable")
func _register_player(new_player_info):
	var new_player_id = multiplayer.get_remote_sender_id()
	
	if multiplayer.is_server():
		var server_mods = player_info['loaded-mods'] # Or players[1]['loaded-mods']
		var joining_mods = new_player_info['loaded-mods']
		
		if !GeneralUtils.check_array_compat(server_mods, joining_mods):
			print('[MULTIPLAYER] Mod mismatch! Kicking peer:', new_player_id)
			multiplayer.multiplayer_peer.disconnect_peer(new_player_id)
			return # STOP execution here. Do not add to dict.
			
	players[new_player_id] = new_player_info
	player_connected.emit(new_player_id, new_player_info)

func _on_player_disconnected(id):
	if (not players[id]["name"] == '') and (not players[id]["connTest"]):
		rpc('_player_send_msg', id, players[id]["name"] + ' saiu da sala\n')
	players.erase(id)
	player_disconnected.emit(id)

func _on_connected_ok():
	var peer_id = multiplayer.get_unique_id()
	players[peer_id] = player_info
	player_connected.emit(peer_id, player_info)
	if player_info["name"] == '': return
	if player_info["connTest"]: return
	rpc('_player_send_msg', peer_id, player_info["name"] + ' entrou na sala\n')


func _on_connected_fail():
	print('[MULTIPLAYER] Fuck. (connection fail)')
	remove_multiplayer_peer()

func _on_server_disconnected():
	remove_multiplayer_peer()
	players.clear()
	server_disconnected.emit()

### Bullshitteria aleatoria sei la mano

@rpc("any_peer", "reliable")
func _spawn_object(name:String, pos:Vector2, variation:String, additionalData:Dictionary, map:String):
	if map == GPStats.curMap:
		var obj = MapUtils.spawn_object_online(name, pos, variation, additionalData)

@rpc("any_peer", "reliable")
func _player_make_hitbox(playerId:Variant, offset:Vector2, scale:Vector2, _damage:float, _knockback:float, _knockAngle:float, hitboxId:String):
	for char in JolasGame.instance.plyNode.get_children():
		if char.get_multiplayer_authority() == playerId:
			if char.has_method('make_hitbox_actual'):
				char.make_hitbox_actual(offset, scale, _damage, _knockback, _knockAngle, hitboxId)

@rpc("any_peer", "reliable")
func _player_delete_hitboxes(playerId:Variant, hitboxId:String = ''):
	for char in JolasGame.instance.plyNode.get_children():
		if char.get_multiplayer_authority() == playerId:
			if char.has_method('delete_hitboxes_actual'):
				char.delete_hitboxes_actual(hitboxId)

@rpc("any_peer", "reliable")
func _player_send_params(playerId:Variant, properties:Dictionary[String, Variant]):
	for char in JolasGame.instance.plyNode.get_children():
		if char.get_multiplayer_authority() == playerId:
			if char.has_method('get_params'):
				char.get_params(properties)

@rpc("any_peer", "call_local", "reliable")
func _player_send_msg(playerId:Variant, message:String):
	JolasGame.instance.hud.add_to_msg_log(message)
