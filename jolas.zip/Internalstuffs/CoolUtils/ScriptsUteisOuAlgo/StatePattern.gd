## roubei do breno hihi
class_name StatePattern extends Node

var States = null
var StateName: String = "null"

func setup():
	pass

func enter_state():
	pass

func exit_state():
	pass

func draw():
	pass

func update():
	pass
