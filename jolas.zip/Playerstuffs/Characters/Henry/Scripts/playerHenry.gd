extends PlayerObject

var gunCooldowns:Array[int] = [0, 0] #i want you to meet my daughters GUN NUMBER 1 AND GUN NUMBER 2
@export var GUN_SPEED_ADD = 50.0

func _process(delta: float) -> void:
	for coold in range(len(gunCooldowns)):
		if gunCooldowns[coold] > 0:
			gunCooldowns[coold] -= 1

func shootEm(gunber:int):
	var gunmanSpeed:float = GUN_SPEED_ADD
	if is_on_floor():
		gunmanSpeed = GUN_SPEED_ADD * 4
	if gunCooldowns[gunber] > 0: return
	jumping = false
	gunCooldowns[gunber] = 10
	
	makeGunClip(gunber)
	play_char_sfx('Pistol', 'Henry', -2)
	plySprite.play('gun' + str(gunber + 1))
	plySprite.set_frame_and_progress(0, 0.0)
	make_hitbox_timed(0.05, Vector2(423.0, 18.0),
	Vector2(36.455, 0.435),
	ATTACK_DMG_LVL['default'],
	1000, 335, 'gun')
	
	# motion.y -= 2
	if Input.is_action_pressed("ctrl_left") \
	or not Input.is_action_pressed("ctrl_right") and plySprite.flip_h:
		if motion.x > gunmanSpeed:
			motion.x += gunmanSpeed * 1.25
		else:
			motion.x += gunmanSpeed
	else:
		if motion.x < -gunmanSpeed:
			motion.x -= gunmanSpeed * 1.25
		else:
			motion.x -= gunmanSpeed

func handleMovement(new_floor_acceleration: float = FLOOR_ACCELERATION, new_air_acceleration: float = AIR_ACCELERATION, new_soft_max_speed: float = SOFT_MAX_SPEED) -> void:
	super.handleMovement(new_floor_acceleration, new_air_acceleration, new_soft_max_speed)
	if movementEnabled:
		if Input.is_action_pressed("ctrl_2"):
			shootEm(0)
		if Input.is_action_just_released("ctrl_2"):
			if gunCooldowns[0] > 0:
				gunCooldowns[0] = 0
		if Input.is_action_pressed("ctrl_1"):
			shootEm(1)
		if Input.is_action_just_released("ctrl_2"):
			if gunCooldowns[1] > 0:
				gunCooldowns[1] = 0

func makeGunClip(gunber:int):
	var gunPos:Array[Vector2] = [
		Vector2(44.0, 14.0),
		Vector2(60.0, 11.0)
	]
	var thingie = GameUtils.get_char_asset("Henry", "Misc/GunFx.tscn").instantiate()
	get_parent().add_child(thingie)
	thingie.position = position + Vector2(gunPos[gunber].x * (-1 if plySprite.flip_h else 1), gunPos[gunber].y)

func on_jump(jumpNum:int):
	super.on_jump(jumpNum)
	if jumpNum > 2:
		var thingie = GameUtils.get_char_asset("Henry", "Misc/JumpFx.tscn").instantiate()
		plySprite.add_child(thingie)
