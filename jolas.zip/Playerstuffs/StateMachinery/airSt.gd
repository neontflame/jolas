extends PlayerStatePattern

func enter_state():
	Player.plySprite.speed_scale = 1;
	Player.shakeForce = 0
	# print('Enter Air')
	await get_tree().process_frame
	
	if Player.jumping == true:
		Player.play_sfx('Jump', 10)
		Player.plySprite.play('jump')
	else:
		Player.plySprite.play('fall')
	
func update():
	Player.handlePhys()
	handleAnimations()
	Player.handleMovement()
	Player.handleCamera()
	Player.apply_player_gravity()
	
	if Player.is_on_floor():
		Player.change_state(Player.state_machine.st_floor)

func handleAnimations():
	if PlayerUtils.is_jump_just_pressed() and (Player.jumpsDone <= Player.JUMP_COUNT):
		if not Player.is_on_floor() and not Player.can_jump_mid_air:
			return
		Player.play_sfx('Jump', 10)
		Player.plySprite.play('jump')
