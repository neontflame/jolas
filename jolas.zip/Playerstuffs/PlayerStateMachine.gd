class_name PlayerStateMachine extends Node

#region Gerais
@onready var st_default: Node = $Default
@onready var st_floor: Node = $Floor
@onready var st_air: Node = $Air
@onready var st_hurt: Node = $Hurt
@onready var st_death: Node = $Death
#endregion
