extends Node
class_name GPStats

static var maxHP := 10
static var lvLimit := 20 # multiplicador pros limites dos niveis eu acho

#region Game stats
static var saveSlot := 0

static var xp := 0
static var level := 7

static var charObject: PlayerObject
static var char := 'Neon'

static var curMap := 'TheThing'
static var curRegion := 'MapaDeTestes'

static var exploredMaps:Array = []
static var bossesBeat:Array = []

static var modded := false
#endregion

#region Multiplayer variables
static var is_multiplayer := false
static var is_dedicated_server := false
static var is_hosting := false
static var multiplayerID:Variant = -1
#endregion

static func setCharObject(thisChar:PlayerObject):
	charObject = thisChar
	charObject.level_up()

static func process(delta: float) -> void:
	if xp > level * lvLimit:
		xp = xp - level * lvLimit
		level += 1
		
		var hpDifference := charObject.hp / GPStats.maxHP
		maxHP += level * 2
		charObject.hp = ceil(maxHP * hpDifference)
		charObject.level_up()

static func load_info_from_save(saveSlot:int):
	var save = SaveUtils.get_save_info(saveSlot)
	
	if save['new'] == true:
		level = 1
		xp = 0
		maxHP = 10
		curMap = GameUtils.defaultMap
		curRegion = GameUtils.get_region_from_map(curMap)
		exploredMaps = []
		bossesBeat = []
		InventoryUtils.inventory = []
		QuestUtils.clear_all()
	else:
		level = save['level']
		xp = save['xp']
		maxHP = save['maxHP']
		curMap = save['map']
		if save.has("region"): curRegion = save['region']
		if save.has("exploredMaps"): exploredMaps = save['exploredMaps']
		if save.has("bossesBeat"): exploredMaps = save['bossesBeat']
		if (save.has("assignedQuests") and save.has("clearedQuests")):
			QuestUtils.assignedQuests = save['assignedQuests']
			QuestUtils.clearedQuests = save['clearedQuests']
		if (save.has("inventory")):
			InventoryUtils.inventory = save['inventory']

static func addToBossesBeat(bossName:String):
	if not bossesBeat.has(bossName):
		bossesBeat.append(bossName)
