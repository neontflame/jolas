extends Node2D
class_name JolasGame

static var instance: JolasGame

@export var coolFade: TextureRect
@export var plyNode: Node2D
@export var lvlNode: Node2D
@export var whereHud: Node2D
@export var bgmStream: AudioStreamPlayer
@export var ingameMenu: Node2D
var hud: HeadsUpDisplay
var map: JolasMap
var playerInstance
var dialogueInstance
var cutsceneInstance:JolasCutscene

static var isChangingMap := false

var mapExploredForFirstTime:bool = false
var curTrackName := ""
var curTrackRegion: RegionSong = null

var isDial := false
var isMenu := false

# variaveis multiplayer !!
var allChars: Array = []
var charDict: Dictionary = {}

func _ready() -> void:
	makeHud()
	createMap(GPStats.curMap, GPStats.curRegion)
	createPlayer(GPStats.char, -1)
	SaveUtils.save_game(GPStats.saveSlot)
	
	if GPStats.is_multiplayer:
		if GPStats.is_hosting:
			create_mp_game()
		else:
			join_mp_game()
	
	JolasGame.instance = self
	isChangingMap = false


#region Os Auxiliares
# The Joy of Creation
# eu nunca joguei fnaf na minha vida na vdd
func createPlayer(chara:String, id:int = -1):
	print("[GAME] Criando char ", chara)
	var player = GameUtils.get_char_asset(chara, chara + ".tscn")
	
	if playerInstance: 
		removePlayer()
	
	playerInstance = player.instantiate()
	playerInstance.playerID = id
	plyNode.add_child(playerInstance)
	allChars.append(playerInstance)
	
	if map:
		if map.get_node("Spawnpoint"):
			playerInstance.position = map.get_node("Spawnpoint").position
		
	GPStats.setCharObject(playerInstance)
	GPStats.charObject.on_respawn(true)

func removePlayer():
	if playerInstance: 
		allChars.erase(playerInstance)
		playerInstance.queue_free()

func createMap(lvl:String, region:String, playerGoTo:String = ""):
	print('[GAME] Criando mapa ' + lvl)
	if map: map.free()
	
	map = load(GameUtils.get_map_path(lvl, region)).instantiate()
	map.info = GameUtils.get_map_info(lvl, region)
	mapExploredForFirstTime = not GPStats.exploredMaps.has(lvl)
	if not GPStats.exploredMaps.has(lvl): GPStats.exploredMaps.append(lvl)
	lvlNode.add_child(map)
	# MapUtils.set_map(map)
	
	await get_tree().process_frame
	GPStats.curMap = lvl
		
	SaveUtils.save_game(GPStats.saveSlot)
	
	if (curTrackRegion == null) \
	or (curTrackRegion != null and \
		((curTrackRegion in map.info.get_songfiles()) and curTrackRegion.loops) \
		or (not (curTrackRegion in map.info.get_songfiles()))
	):
		var songPlayed:RegionSong = map.info.get_songfiles().pick_random()
		playBGM(songPlayed)
		triggerPlaceInfo(songPlayed)
	
	#potential
	if playerGoTo != "":
		respawnPlayer(false, playerGoTo)
		if not isMenu:
			GPStats.charObject.process_mode = Node.PROCESS_MODE_INHERIT
			JolasGame.isChangingMap = false

func triggerPlaceInfo(songPlayed:RegionSong, canPlace:bool = true):
	hud.placeInfo.queue_free()
	hud.placeInfo = load("res://Gamestuffs/HeadsUpDisplay/placeInfo.tscn").instantiate()
	hud.get_node("CanvasLayer/Control").add_child(hud.placeInfo)
	hud.placeInfo.position = Vector2(20.0, 21.0)
	hud.placeInfo.canPlace = canPlace
	hud.placeInfo.triggerPlaceInfo(songPlayed)

func respawnPlayer(maxOutHP:bool = true, spawnNode:String = "Spawnpoint"):
	if map:
		if map.get_node_or_null(spawnNode):
			GPStats.charObject.position = map.get_node(spawnNode).position
	
	if maxOutHP: GPStats.charObject.hp = GPStats.maxHP
	GPStats.charObject.change_state(GPStats.charObject.state_machine.st_floor)
	GPStats.charObject.on_respawn(maxOutHP)
	GPStats.charObject.setup_camera()

#acaba os treco de player
var fadeTween:Tween = create_tween()
func fadeOut(sec:float, callThat:Callable = func():pass):
	if fadeTween:
		fadeTween.kill()
		
	await get_tree().process_frame
	fadeTween = create_tween()
	fadeTween.tween_method(
		func(value): 
			coolFade.self_modulate.a = value
			if value <= 0.0:
				coolFade.visible = false
				callThat.call()
			,  
		1.0,  # Start value
		0.0,  # End value
		sec     # Duration
	)

func fadeIn(sec:float, callThat:Callable = func():pass):
	if fadeTween:
		fadeTween.kill()
	
	coolFade.visible = true
	fadeTween = create_tween()
	fadeTween.tween_method(
		func(value): 
			coolFade.self_modulate.a = value
			if value >= 1.0:
				callThat.call()
			,  
		0.0,  # Start value
		1.0,  # End value
		sec     # Duration
	)

func pauseGame():
	for playery in allChars:
		playery.movementEnabled = false
	for child in get_children():
		if child == dialogueInstance \
		or child == bgmStream \
		or child == coolFade \
		or child == ingameMenu: continue
		child.process_mode = PROCESS_MODE_DISABLED

func unpauseGame():
	for playery in allChars:
		playery.movementEnabled = playery.get_multi_status()
	for child in get_children():
		if child == dialogueInstance \
		or child == bgmStream \
		or child == coolFade \
		or child == ingameMenu: continue
		child.process_mode = PROCESS_MODE_INHERIT

func makeHud(where:String = "res://Gamestuffs/HeadsUpDisplay/hud.tscn"):
	for child in whereHud.get_children():
		child.free()
	hud = null
	
	var newHud = load(where).instantiate()
	whereHud.add_child(newHud)
	hud = newHud
#endregion

#region Diálogo
# DIALOGO....
func endDialogue() -> void:
	isDial = false
	unpauseGame()
	dialogueInstance.disconnect('dialogue_end', endDialogue)
	remove_child(dialogueInstance)

# todo: fazer algo que deixe voce inicializar dialogo sem especificar o tipo
## tipos de dialogo por enquanto incluem:
## - DiagCharacters
func playDialogue(diagName:String, type:String = "DiagCharacters"):
	if !isDial:
		isDial = true
		pauseGame()
		if dialogueInstance: dialogueInstance.queue_free()
		dialogueInstance = load("res://Storystuffs/DiagSystem/%s.tscn" % type).instantiate()
		add_child(dialogueInstance)
		dialogueInstance.parseDialogue(diagName)
		dialogueInstance.connect('dialogue_end', endDialogue)
#endregion

#region Cutscenes
var cutsceneFades:bool = true
var cutsceneStopsSong:bool = true

func startCutscene(cutscene:String, stopsSong:bool = false, fades:bool = true):
	print('criando ', cutscene)
	cutsceneFades = fades
	cutsceneStopsSong = stopsSong
	
	if cutsceneFades:
		fadeOut(0.5, func():pass)
	var leCut:JolasCutscene = load("res://Storystuffs/Cutscenes/%s/Cutscene.tscn" % cutscene).instantiate()
	add_child(leCut)
	cutsceneInstance = leCut
	hud.canvasLayer.visible = false
	$Level.visible = false
	$Players.visible = false
	
	cutsceneInstance.cutsceneEnd.connect(endCutscene)
	
	isDial = true
	pauseGame()
	
	cutsceneInstance.process_mode = Node.PROCESS_MODE_ALWAYS
	
	await get_tree().process_frame
	if stopsSong:
		stopBGM()
	

func startVideoCutscene(vid:String, stopsSong:bool = true, fades:bool = true):
	startCutscene("VideoCutscene", stopsSong, fades)
	cutsceneInstance.playVid(vid)

func endCutscene():
	if cutsceneFades:
		fadeIn(0.5, func():
			backFromCutscenery()
			fadeOut(0.5, func():pass)
		)
	else:
		backFromCutscenery()

func backFromCutscenery():
	cutsceneInstance.queue_free()
	isDial = false
	unpauseGame()
	
	hud.canvasLayer.visible = true
	$Level.visible = true
	$Players.visible = true
	
	if cutsceneStopsSong:
		var songPlayed:RegionSong = map.info.get_songfiles().pick_random()
		playBGM(songPlayed)
		await get_tree().process_frame
		triggerPlaceInfo(songPlayed)

#endregion

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	GPStats.process(_delta)
	
	if not isDial and not isMenu:
		if (not hud.isWriting) and (not isChangingMap):
			if Input.is_action_just_pressed("ctrl_pause"):
				pauseGame()
				ingameMenu.makeMenu('Pause')
			if Input.is_action_just_pressed("ctrl_quests"):
				pauseGame()
				ingameMenu.makeMenu('Quests')
			if Input.is_action_just_pressed("ctrl_inventory"):
				pauseGame()
				ingameMenu.makeMenu('Inventory')
		
#region Multiplayer
func join_mp_game():
	removePlayer()
	removeFromPeerID(multiplayer.get_unique_id())
	$Multiplayer.join_game(OnlineUtils.ipEntered)

func create_mp_game():
	removePlayer()
	removeFromPeerID(multiplayer.get_unique_id())
	$Multiplayer.create_game()

func _on_player_connected(peer_id: Variant, player_info: Variant) -> void:
	removeFromPeerID(peer_id)
	
	if player_info["connTest"]: return
	var playery = GameUtils.get_char_asset(player_info['char'], player_info['char'] + ".tscn")
	var pInst = playery.instantiate()
	pInst.playerID = peer_id
	pInst.name = str(peer_id)
	plyNode.add_child(pInst, true)
	allChars.append(pInst)
	charDict[peer_id] = pInst
	
	if map:
		pInst.position = map.get_node("Spawnpoint").position
		
	pInst.movementEnabled = pInst.get_multi_status()
	pInst.level_up()
	# print('== CHAR DICT ==')
	# print(charDict)
	# print('== END CHAR DICT ==')

func _on_player_disconnected(peer_id: Variant) -> void:
	removeFromPeerID(peer_id)

func removeFromPeerID(peer_id:Variant):
	if charDict.has(peer_id):
		allChars.erase(charDict[peer_id])
		charDict[peer_id].queue_free()
		charDict.erase(peer_id)

func bye_bye() -> void:
	CoolMenu.comingFrom = 'OnlineMenu'
	GeneralUtils.loadScene("res://Menustuffs/Menu.tscn")

func _exit_tree() -> void:
	OnlineUtils.closeUPNPThread()
#endregion

#region Música
func playBGM(track:Variant, showInfo:bool = false):
	if track is RegionSong:
		if curTrackName == track.get_filename(): return
		curTrackName = track.get_filename()
		curTrackRegion = track
		
		bgmStream.stream = track.songfile
		if showInfo:
			triggerPlaceInfo(track, false)
	elif track is String:
		var pathness = "res://Soundstuffs/Music/" + track
		if curTrackName == track: return
		curTrackName = track
		curTrackRegion = null
		
		bgmStream.stream = load(pathness)
	bgmStream.volume_db = 0.0
	bgmStream.play()
	if not bgmStream.finished.is_connected(onBGMFinished):
		bgmStream.finished.connect(onBGMFinished)

func onBGMFinished():
	curTrackName = ""
	if curTrackRegion:
		var songPlayed:RegionSong = map.info.get_songfiles().pick_random()
		playBGM(songPlayed, true)

func fadeBGM(sec:float = 1.0, nextSong:Variant = null):
	var mustween = get_tree().create_tween()
	mustween.tween_method(func(v):
		bgmStream.volume_db = v
		if v <= -99.5:
			bgmStream.stop()
			
			if nextSong:
				mustween.kill()
				playBGM(nextSong, true),
		0.0,
		-100.0,
		sec
		)
	
func stopBGM():
	curTrackName = ""
	PlaceDisplayerIngame.current_song = ""
	bgmStream.stop()
#endregion
