extends "res://Menustuffs/Submenu.gd"

var menuCoolios:Array = []
var menuNames:Array = []

var isSelected:bool = false

@export var mobilery:Node2D

func randomQuote():
	var quotes := [
		'bosta em lata',
		'como se fala akuma ao contrario',
		'musculão saltitoso',
		'QUAL É A CORRENTE MILAGROSA.',
		's saoo po\'\' n the AAAAsta wgo a',
		'*eu nao respondo, minha transformação em chiclete foi total*',
		'MEU SANTO PORPETONE !!',
		'o hawnt xinga o maujoa',
		'FALA PORTUGUES GATO DESGRAÇADO',
		'eu preciso lavar seu cerebro',
		'Insert shocking scene here',
		'sua mae nao sabe plantar um furico sequer',
		'dave',
		'Shii',
		'o queijo .',
		'bomba nuclear de bosta',
		'roubar o banco e tacar fogo em',
		'"Sir, have you been pissing tonight?"',
		'who up colorindo they textinho',
		'hihi quando',
		'lembra daquela vez que EU e o speed tentamos nao rir',
		'lembra daquela vez que eu o hawnt o sketcher o springus\no sushi e o speed tentamos nao rir',
		'MINHA MAE É PARCIALMENTE PENDENDO A SER MENDIGA',
		'cara vai se fuder\ncom a porra do seu mr beast',
		'gifted goons vs hard work goons',
		'opa eaí webcore!',
		'"20 dolares e 20 dolares"',
		'cara eu estou jolando cara',
		'ESSA NÃO É UMA CALL DE GAMEDEV',
		'nem te conto',
		'',
		'eu tambem to no\nmenu principal - henry'
	]
	return quotes[randi_range(0, len(quotes) - 1)]
	
func _ready() -> void:
	if OS.get_name() == "Web":
		$MenuCanvas/RightAnchor/Opts/addons.modulate.a = 0.5
		$MenuCanvas/RightAnchor/Opts/sair.modulate.a = 0.5
	
	var versionStringness:String = GameUtils.gameVersion
	if GameUtils.captionVersion != null && GameUtils.captionVersion != "":
		versionStringness += " (%s)" % GameUtils.captionVersion
	
	$MenuCanvas/Label.text = "[b]versão %s[/b]
jogo feito por [b]neontflame[/b], direitos autorais uhhhhhh pipipi popopo???
termo \"jolas\" cunhado por hawnt, sketcher e zummy" % versionStringness
	$MenuCanvas/Quote.text = randomQuote()
	
	for child in $MenuCanvas/RightAnchor/Opts.get_children():
		menuCoolios.append(child)
	
	if GameUtils.isMobile:
		for mobthing in mobilery.get_children():
			mobthing.doThing.connect(func(id):
				if CoolMenu.curSelected == id:
					goToMenu(menuCoolios[CoolMenu.curSelected].name)
				if CoolMenu.curSelected != id:
					CoolMenu.play_sfx('Tick')
					CoolMenu.curSelected = id
				)
	else:
		mobilery.queue_free()
	
	CoolMenu.maxSelected = len(menuCoolios)
	CoolMenu.blurAmount = 0.0
	CoolMenu.activeMusicLayers = 1
	
var optWidth := 253.0
func _process(delta: float) -> void:
	for menuOpt in menuCoolios:
		if menuCoolios[CoolMenu.curSelected] == menuOpt:
			menuOpt.play('active')
			menuOpt.position.x = lerp(menuOpt.position.x, -16.0, 0.2)
			menuOpt.self_modulate.a = 1
		else:
			menuOpt.play('inactive')
			menuOpt.position.x = lerp(menuOpt.position.x, 0.0, 0.2)
			menuOpt.self_modulate.a = 0.5
	
	if !isSelected:
		if Input.is_action_just_pressed('ui_down'):
			CoolMenu.play_sfx('Tick')
			CoolMenu.curSelected = wrap(CoolMenu.curSelected + 1, 0, CoolMenu.maxSelected)
		if Input.is_action_just_pressed('ui_up'):
			CoolMenu.play_sfx('Tick')
			CoolMenu.curSelected = wrap(CoolMenu.curSelected - 1, 0, CoolMenu.maxSelected)
		
		if Input.is_action_just_pressed('ui_accept'):
			goToMenu(menuCoolios[CoolMenu.curSelected].name)

func goToMenu(menuName:String):
	CoolMenu.play_sfx('Go')
	match menuName:
		'jolar':
			GPStats.is_multiplayer = false
			whiteTweenTo("res://Menustuffs/SaveMenu/SaveMenu.tscn")
		'jolarCoop':
			GPStats.is_multiplayer = true
			change_self_scene("res://Menustuffs/OnlineMenu/OnlineMenu.tscn")
		'opcoes':
			change_self_scene("res://Menustuffs/OptionsMenu/OptionsMenu.tscn")
		'addons':
			if OS.get_name() != "Web":
				change_self_scene("res://Menustuffs/Main/Addons/Addons.tscn")
			else:
				CoolMenu.stop_sfx('Go')
				CoolMenu.play_sfx('Back')
		'sobre':
			change_self_scene("res://Menustuffs/AboutMenu/AboutMenu.tscn")
		'sair':
			if OS.get_name() != "Web":
				get_tree().quit()
			else:
				CoolMenu.stop_sfx('Go')
				CoolMenu.play_sfx('Back')
		_:
			print(menuName)
			CoolMenu.stop_sfx('Go')
			CoolMenu.play_sfx('Back')

func whiteTweenTo(scene:String):
	isSelected = true
	var coolTweens = create_tween()
	$MenuCanvas/FadeRect.self_modulate.a = 0.0
	$MenuCanvas/FadeRect.visible = true
	coolTweens.tween_method(
					func(value): 
						$MenuCanvas/FadeRect.self_modulate.a = value
						if value >= 1:
							change_self_scene(scene)
						,  
					0.0,  # Start value
					1.0,  # End value
					0.3    # Duration
				)

func whiteTweenFrom():
	var coolTweens = create_tween()
	$MenuCanvas/FadeRect.self_modulate.a = 1.0
	$MenuCanvas/FadeRect.visible = true
	coolTweens.tween_method(
					func(value): 
						$MenuCanvas/FadeRect.self_modulate.a = value
						,  
					1.0,  # Start value
					0.0,  # End value
					0.3    # Duration
				)
