extends Node2D
class_name SaveBox

var saveId:int = 0
signal onClicked

func renderSave():
	var coolSaveness:Dictionary = SaveUtils.get_save_info(saveId)
	print('save id: ' + str(saveId))
	print(coolSaveness)
	
	if coolSaveness["new"] == true:
		$FullSave.visible = false
		$EmptySave.visible = true
		$SaveBox.play('empty')
	else:
		$EmptySave.visible = false
		$FullSave.visible = true
		# player info
		
		$FullSave/CanvasGroup/Icon.texture = GameUtils.get_char_asset(coolSaveness["player"], "IconCard.png")
		
		var hueShift = fmod((coolSaveness["level"] - 1) * 7.5, 100.0) / 100.0
		$FullSave/LvCount.text = str(GeneralUtils.display_number(coolSaveness["level"]))
		$FullSave/LvCount.add_theme_color_override("font_color", Color.from_hsv(0.61 + hueShift, 0.6, 1.0, 1.0))
		
		var mapInfo = GameUtils.get_map_info(coolSaveness["map"], coolSaveness["region"])
		$FullSave/CurMap.text = mapInfo.name + ' - ' + mapInfo.region.name
		# $FullSave/Timespan.text = timeString
		$FullSave/CurChar.text = GameUtils.get_char_info(coolSaveness["player"])["name"]
		
		if coolSaveness["applied-mods"] != []:
			$SaveBox.play('mod')

func renderPaused():
	$EmptySave.visible = false
	$FullSave.visible = true
	# player info
	$FullSave/CanvasGroup/Icon.texture = GameUtils.get_char_asset(GPStats.char, "IconCard.png")
	
	var hueShift = fmod((GPStats.level - 1) * 7.5, 100.0) / 100.0
	$FullSave/LvCount.text = str(GeneralUtils.display_number(GPStats.level))
	$FullSave/LvCount.add_theme_color_override("font_color", Color.from_hsv(0.61 + hueShift, 0.6, 1.0, 1.0))
	
	var mapInfo = GameUtils.get_map_info(GPStats.curMap, GPStats.curRegion)
	$FullSave/CurMap.text = mapInfo.name + ' - ' + mapInfo.region.name
	# $FullSave/Timespan.text = timeString
	$FullSave/CurChar.text = GameUtils.get_char_info(GPStats.char)["name"]
	
	if ModUtils.loadedMods != []:
		$SaveBox.play('mod')

func renderSaveOnline():
	var coolSaveness:Dictionary = SaveUtils.get_save_info(saveId)
	
	print(GPStats.char)
	$Icon.texture = GameUtils.get_char_asset(GPStats.char, "Icon.png")
	$CurChar.text = GameUtils.get_char_info(GPStats.char)["name"]
	
	if coolSaveness["new"] == true:
		$FullSave.visible = false
		$EmptySave.visible = true
	else:
		$EmptySave.visible = false
		$FullSave.visible = true
		# player info
		$FullSave/LvCount.text = tr('oldsave_lvcount') % GeneralUtils.display_number(coolSaveness["level"])
		var mapInfo = GameUtils.get_map_info(coolSaveness["map"], coolSaveness["region"])
		$FullSave/CurMap.text = mapInfo.name + ' - ' + mapInfo.region.name
		# $FullSave/Timespan.text = timeString

		if ModUtils.loadedMods != []:
			$SaveBox.self_modulate.b = 0
			$ModWarning.visible = true
		else:
			$SaveBox.self_modulate.b = 1
			$ModWarning.visible = false
	pass

func _on_area_2d_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if Input.is_action_just_pressed("ui_click"):
		onClicked.emit()
