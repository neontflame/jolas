extends "res://Menustuffs/Submenu.gd"

var curPath:String = FileUtils.get_user_path()
var root:String = FileUtils.get_user_path()
var curItems:Array = []

@export var boxWithABunchOfShitInIt:VBoxContainer

func _ready() -> void:
	CoolMenu.blurAmount = 2
	CoolMenu.activeMusicLayers = 2
	reload()
	pass

func reload():
	CoolMenu.curSelected = 0
	$MenuCanvas/MidAnchor/PathLabel.text = curPath
	curItems = []
	for file in DirAccess.get_directories_at(curPath):
		curItems.append(file + '/')
	for file in DirAccess.get_files_at(curPath):
		curItems.append(file)
		
	# print(curItems)
	if curPath != root:
		curItems.push_front('../')
	CoolMenu.maxSelected = len(curItems)
	
	for child in boxWithABunchOfShitInIt.get_children():
		boxWithABunchOfShitInIt.remove_child(child)
	
	var i:int = 0
	
	for item in curItems:
		var newFile = load("res://Menustuffs/AddonsMenu/FileThingie.tscn").instantiate()
		boxWithABunchOfShitInIt.add_child(newFile)
		newFile.filename = item
		newFile.folder = curPath
		newFile.setup()
		if ModUtils.loadedMods.has(curPath + newFile.filename):
			newFile.applied = true
		newFile.id = i
		i += 1

func _process(delta: float) -> void:
	$MenuCanvas/MidAnchor/ModLabel.text = tr_n('mod_loaded_single', 'mod_loaded_plural', len(ModUtils.loadedMods)) % len(ModUtils.loadedMods)
	if len(ModUtils.queuedMods) > 0:
		$MenuCanvas/MidAnchor/ModLabel.text += tr_n('mod_queued_single', 'mod_queued_plural', len(ModUtils.queuedMods)) % len(ModUtils.queuedMods)
	
	for coolfile in boxWithABunchOfShitInIt.get_children():
		if CoolMenu.curSelected != -1:
			coolfile.selected = (coolfile.filename == curItems[CoolMenu.curSelected])
		else:
			coolfile.selected = false
		coolfile.applied = (ModUtils.loadedMods.has(curPath + coolfile.filename) \
						or ModUtils.queuedMods.has(curPath + coolfile.filename))
		
	if Input.is_action_just_pressed("ui_down"):
		CoolMenu.curSelected = wrap(CoolMenu.curSelected + 1, 0, CoolMenu.maxSelected)
		$MenuCanvas/MidAnchor/ScrollContainer.scroll_vertical = boxWithABunchOfShitInIt.get_children()[CoolMenu.curSelected].position.y
		CoolMenu.play_sfx('Tick')
	if Input.is_action_just_pressed("ui_up"):
		CoolMenu.curSelected = wrap(CoolMenu.curSelected - 1, 0, CoolMenu.maxSelected)
		$MenuCanvas/MidAnchor/ScrollContainer.scroll_vertical = boxWithABunchOfShitInIt.get_children()[CoolMenu.curSelected].position.y
		CoolMenu.play_sfx('Tick')
	if Input.is_action_just_pressed('ui_cancel'):
		goBack()
		
	if CoolMenu.curSelected != -1:
		if Input.is_action_just_pressed("ui_accept") || Input.is_action_just_pressed('ui_click'):
			if curItems[CoolMenu.curSelected] == '../':
				goBack()
			elif curItems[CoolMenu.curSelected].ends_with('/'):
				curPath += curItems[CoolMenu.curSelected]
				# print(curPath)
				reload()
				CoolMenu.play_sfx('Tick')
			elif curItems[CoolMenu.curSelected].ends_with('.pck') || curItems[CoolMenu.curSelected].ends_with('.zip') :
				loadMod(curPath + curItems[CoolMenu.curSelected])


func loadMod(mod:String):
	if !ModUtils.loadedMods.has(mod):
		if ModUtils.is_mod_compatible(mod):
			if ModUtils.get_mod_info(mod)['restartsGame']:
				if not ModUtils.queuedMods.has(mod):
					ModUtils.queuedMods.append(mod)
			else:
				ProjectSettings.load_resource_pack(ModUtils.get_mod_path(mod))
				ModUtils.loadedMods.append(mod)
				# carregar scripts !!!
				# pra quem for maluco e fizer algum mod maluco que precise
				if len(ModUtils.get_mod_info(mod)['runOnLoad']) > 0:
					for modscript in ModUtils.get_mod_info(mod)['runOnLoad']:
						var script = load(modscript).new()
						get_tree().root.add_child(script)
			CoolMenu.play_sfx('Go')

func goBack():
	CoolMenu.play_sfx('Back')
	if curPath == root:
		if len(ModUtils.queuedMods) > 0:
			CoolMenu.curSelected = 0
			ModUtils.queuedMods.reverse()
			get_tree().change_scene_to_file('res://DontTouchstuffs/QueuedModLoader.tscn')
		else:
			CoolMenu.curSelected = 4
			await get_tree().process_frame
			change_self_scene('res://Menustuffs/MainMenu/MainMenu.tscn')
	else:
		# e hora de voltar
		var lessPath:Array = curPath.split('/')
		lessPath.resize(lessPath.size() - 2)
		# print(lessPath)
		
		curPath = ''
		for lesser in lessPath:
			curPath += lesser
			curPath += '/'
			
		# print(curPath)
		reload()
