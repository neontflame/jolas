extends Submenu
class_name FastTravelMenu

@export var mapinha:LugarMapa
var canControl:bool = true
var regionString:String = ""

func _ready() -> void:
	CoolMenu.play_sfx('Unwrap')
	$AnimationPlayer.play('getIn')
	mapinha.changeMap(GPStats.curRegion)

func _process(_delta: float) -> void:
	$MenuCanvas/LeftAnchor/Esc.visible = canControl
	if canControl:
		if Input.is_action_just_pressed("ui_cancel"):
			canControl = false
			CoolMenu.play_sfx('Wrap')
			$AnimationPlayer.play('getOut')
			await get_tree().create_timer(0.5).timeout
			change_self_scene('res://Menustuffs/Ingame/Pause/Pause.tscn', 1)

func goToThing(mapId:String):
	print("[FASTTRAVEL] Id do mapa: ", mapId)
	canControl = false
	CoolMenu.play_sfx('Wrap')
	$AnimationPlayer.play('getOut')
	await get_tree().create_timer(0.5).timeout
	
	JolasGame.instance.unpauseGame()
	JolasGame.instance.hud.questIcon.rerenderCtrl()
	JolasGame.instance.hud.inventoryIcon.rerenderCtrl()
	GPStats.charObject.onUnpause()
	CoolMenu.instance.unmakeMenu()
	
	JolasGame.instance.fadeIn(0.5, 
	func(): 
		print('[FASTTRAVEL] ok agora volta')
		JolasGame.instance.createMap(mapId, regionString)
		JolasGame.instance.respawnPlayer(false, "Spawnpoint")
		JolasGame.instance.fadeOut(0.5)
		)
