extends Node2D
class_name CoolMenu

static var curMenu:String = 'Main'
static var curSelected:int = 0
static var maxSelected:int = 0

static var activeMusicLayers:int = 1
static var blurAmount:float = 0.0

static var instance:Node2D

static var comingFrom = ''

@export var camera: Camera2D
@export var blurfx:TextureRect

var theVolumes:Array = [0.0, 0.0, 0.0]

func _ready() -> void:
	CoolMenu.instance = self
	CoolMenu.curMenu = 'Main'
	
	manageTrackVolumes()
	
	$BGMLayered.play()
	
	if CoolMenu.comingFrom != '':
		$MainMenu.change_self_scene('res://Menustuffs/' + comingFrom + '/' + comingFrom + '.tscn')
		CoolMenu.comingFrom = ''

var sineWaveCoolio := 0.0

func _process(delta: float) -> void:
	camera.position.x -= 50.0 * delta
	# camera.position.x = (sin(sineWaveCoolio) * (96.0/2.0)) + 354.0
	
	sineWaveCoolio += delta/8.0
	$MenuBg.position.x = (sin(sineWaveCoolio) * (96.0/2.0)) + 354.0
	
	blurfx.material.set_shader_parameter("amount", lerp(blurfx.material.get_shader_parameter("amount"), blurAmount, 0.2))
	
	manageTrackVolumes()

static func play_sfx(sfxName:String):
	if !CoolMenu.instance: return
	CoolMenu.instance.get_node('SFX/' + sfxName).play()
	
static func stop_sfx(sfxName:String):
	if !CoolMenu.instance: return
	CoolMenu.instance.get_node('SFX/' + sfxName).stop()

func manageTrackVolumes():
	for vol in range(len(theVolumes)):
		if vol < CoolMenu.activeMusicLayers:
			theVolumes[vol] = 0.0
		else:
			theVolumes[vol] = linear_to_db(0.001)
		$BGMLayered.stream.set_sync_stream_volume(vol, 
		lerp(
			$BGMLayered.stream.get_sync_stream_volume(vol),
			theVolumes[vol],
			0.2
		))
	#for trackNum in range(len(theMusics)):
		#var coolume = theVolumes[trackNum]
		#theMusics[trackNum].volume_db = (coolume if !is_nan(coolume) else theVolumes[trackNum]) 
